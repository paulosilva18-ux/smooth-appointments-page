/** Gera slots de 30 em 30 min, incluindo o horário final. */
function faixa(inicio: string, fim: string): string[] {
  const [hi, mi] = inicio.split(":").map(Number) as [number, number];
  const [hf, mf] = fim.split(":").map(Number) as [number, number];
  const out: string[] = [];
  for (let m = hi * 60 + mi; m <= hf * 60 + mf; m += 30) {
    out.push(`${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`);
  }
  return out;
}

export const HORARIOS = [...faixa("09:00", "12:00"), ...faixa("14:00", "19:00")];

/** Faixas por dia da semana (0 = domingo). */
const AGENDA_SEMANA: Record<string, Record<number, [string, string][]>> = {
  "Fabrício": {
    1: [["09:00", "12:00"], ["14:00", "18:00"]],
    2: [["09:00", "12:00"], ["14:00", "18:00"]],
    3: [["09:00", "12:00"], ["14:00", "18:00"]],
    4: [["08:30", "12:00"], ["14:00", "19:00"]],
    5: [["09:30", "13:00"], ["14:00", "19:30"]],
    6: [["08:00", "13:00"], ["14:00", "18:30"]],
  },
  "Victor Paz": {
    1: [["10:00", "12:00"], ["15:00", "18:00"]],
    2: [["10:00", "12:00"], ["15:00", "18:00"]],
    3: [["10:00", "12:00"], ["15:00", "18:00"]],
    4: [["10:00", "12:00"], ["15:00", "18:00"]],
    5: [["09:30", "12:00"], ["15:00", "18:00"]],
    6: [["10:00", "12:00"], ["14:00", "18:00"]],
  },
};

/** Grade completa do barbeiro (união de todos os dias) — usada como fallback. */
export const HORARIOS_POR_BARBEIRO: Record<string, string[]> = Object.fromEntries(
  Object.entries(AGENDA_SEMANA).map(([nome, dias]) => [
    nome,
    [...new Set(Object.values(dias).flatMap((fs) => fs.flatMap(([a, b]) => faixa(a, b))))].sort(),
  ]),
);

function diaSemana(data?: string): number | null {
  if (!data) return null;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) return null;
  const t = Date.parse(`${data}T12:00:00-03:00`);
  if (Number.isNaN(t)) return null;
  return new Date(t).getUTCDay();
}

/** Turnos reais; a permissão para iniciar no encerramento é aplicada em duracao.ts. */
export function turnosDoBarbeiro(nome: string, data: string): [string, string][] {
  const dow = diaSemana(data);
  if (dow === null) return [];
  return AGENDA_SEMANA[nome]?.[dow] ?? [];
}

/**
 * Limite inclusivo de início no último turno: o serviço pode terminar depois
 * do encerramento. Configurado por barbeiro e dia (0 = domingo).
 */
const ULTIMO_INICIO: Record<string, Record<number, string>> = {
  "Fabrício": {
    1: "18:00",
    2: "18:00",
    3: "18:00",
    4: "19:00",
    5: "19:30",
    6: "18:30",
  },
};

export function ultimoInicio(nome: string, data: string): string | null {
  const extra = ULTIMO_INICIO[nome]?.[diaSemana(data) ?? -1];
  if (!extra) return null;
  return turnosDoBarbeiro(nome, data).some(([, fim]) => fim === extra) ? extra : null;
}

export function horariosDoBarbeiro(nome: string, data?: string): string[] {
  const semana = AGENDA_SEMANA[nome];
  if (!semana) return HORARIOS;
  const dow = diaSemana(data);
  if (dow === null) return HORARIOS_POR_BARBEIRO[nome] ?? HORARIOS;
  return (semana[dow] ?? []).flatMap(([a, b]) => faixa(a, b));
}

const STORAGE_KEY = "fb-agendamentos";

/** Janela mínima (em horas) para cancelar ou remarcar um horário. */
export const JANELA_CANCELAMENTO_HORAS = 3;

export const POLITICA_CANCELAMENTO = `Cancelamentos e remarcações são permitidos até ${JANELA_CANCELAMENTO_HORAS} horas antes do horário marcado. Depois disso, fale direto com o barbeiro no WhatsApp.`;

/** Converte data (YYYY-MM-DD) + hora (HH:MM) no fuso de Pernambuco (UTC-3). */
export function instanteAgendamento(data: string, hora: string): number {
  return Date.parse(`${data}T${hora}:00-03:00`);
}

export function dentroDaJanela(data: string, hora: string, agora = Date.now()): boolean {
  const inicio = instanteAgendamento(data, hora);
  if (Number.isNaN(inicio)) return true;
  return inicio - agora >= JANELA_CANCELAMENTO_HORAS * 60 * 60 * 1000;
}

export function lidosIds(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const arr = raw ? (JSON.parse(raw) as unknown) : [];
    return Array.isArray(arr) ? arr.filter((v): v is string => typeof v === "string") : [];
  } catch {
    return [];
  }
}

export function salvarId(id: string) {
  if (typeof window === "undefined") return;
  const ids = lidosIds();
  if (!ids.includes(id)) {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify([...ids, id]));
  }
}

export function removerId(id: string) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify(lidosIds().filter((v) => v !== id)),
  );
}
