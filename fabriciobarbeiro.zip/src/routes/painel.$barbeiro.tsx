import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  entrarPainel,
  sairPainel,
  statusPainel,
  agendaDoBarbeiro,
  cancelarComoBarbeiro,
  remarcarComoBarbeiro,
} from "@/lib/painel.functions";
import { nomePorSlug, formatarData } from "@/lib/painel";
import { SERVICOS, BARBEIROS } from "@/lib/barbearia";
import { duracaoServico, horariosDisponiveis } from "@/lib/duracao";
import { classesStatus, rotuloStatus, statusDoDia, useHojeIso } from "@/lib/statusDia";
import { useAvisoAgendamento } from "@/lib/useAvisoAgendamento";
import { ResumoFaturamento, FaturamentoPorServico } from "@/components/barbearia/ResumoFaturamento";
import { calcularFaturamento } from "@/lib/faturamento";
import {
  Scissors,
  Calendar,
  Clock,
  DollarSign,
  LogOut,
  Trash2,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Volume2,
  VolumeX,
  Bell,
  BellOff,
  Phone,
} from "lucide-react";

export const Route = createFileRoute("/painel/$barbeiro")({
  head: ({ params }) => ({
    meta: [
      { title: `Painel ${nomePorSlug(params.barbeiro) ?? ""} — Fabrício Barbeiro` },
      { name: "description", content: "Painel administrativo da barbearia." },
      { property: "og:title", content: `Painel ${nomePorSlug(params.barbeiro) ?? "Barbeiro"} — Fabrício Barbeiro` },
      { property: "og:description", content: "Painel administrativo da barbearia." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: PainelBarbeiro,
});

function PainelBarbeiro() {
  const { barbeiro } = Route.useParams();
  const nome = nomePorSlug(barbeiro);
  const queryClient = useQueryClient();

  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [aba, setAba] = useState<"agenda" | "servicos" | "faturamento">("agenda");
  const [remarcandoId, setRemarcandoId] = useState<string | null>(null);
  const [novaData, setNovaData] = useState("");
  const [novaHora, setNovaHora] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  const doEntrar = useServerFn(entrarPainel);
  const doSair = useServerFn(sairPainel);
  const doStatus = useServerFn(statusPainel);
  const doAgenda = useServerFn(agendaDoBarbeiro);
  const doCancelar = useServerFn(cancelarComoBarbeiro);
  const doRemarcar = useServerFn(remarcarComoBarbeiro);

  const { data: status } = useQuery({
    queryKey: ["painel-status", barbeiro],
    queryFn: () => doStatus({ data: { slug: barbeiro } }),
    refetchOnWindowFocus: false,
  });

  const { data: agendaData, refetch: refetchAgenda } = useQuery({
    queryKey: ["painel-agenda", barbeiro],
    queryFn: () => doAgenda({ data: { slug: barbeiro } }),
    enabled: status?.autenticado === true,
    refetchOnWindowFocus: true,
    refetchInterval: 3000,
    refetchIntervalInBackground: true,
  });
  const aviso = useAvisoAgendamento(
    status?.autenticado ? agendaData?.agendamentos : undefined,
    `${barbeiro}:${status?.autenticado ?? false}`,
  );
  const [agoraTs, setAgoraTs] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setAgoraTs(Date.now()), 5000);
    return () => clearInterval(t);
  }, []);

  if (!nome) {
    return (
      <main className="min-h-screen bg-[#141414] text-stone-100 flex items-center justify-center p-6">
        <div className="text-center">
          <h1 className="text-2xl font-bold">Painel não encontrado</h1>
          <Link to="/painel" className="mt-4 inline-block text-amber-500 hover:underline">
            Voltar
          </Link>
        </div>
      </main>
    );
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErro(null);
    const res = await doEntrar({ data: { slug: barbeiro, senha } });
    if (!res.ok) {
      setErro("Senha incorreta.");
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["painel-status", barbeiro] });
    setSenha("");
  };

  const handleSair = async () => {
    await doSair();
    queryClient.invalidateQueries({ queryKey: ["painel-status", barbeiro] });
  };

  const handleCancelar = async (id: string) => {
    if (!confirm("Cancelar este agendamento?")) return;
    await doCancelar({ data: { slug: barbeiro, id } });
    refetchAgenda();
    setMsg("Agendamento cancelado.");
  };

  const iniciarRemarcar = (item: { id: string; data: string; hora: string }) => {
    setRemarcandoId(item.id);
    setNovaData(item.data);
    setNovaHora(item.hora);
    setMsg(null);
  };

  const handleRemarcar = async (id: string) => {
    const res = await doRemarcar({ data: { slug: barbeiro, id, data: novaData, hora: novaHora } });
    if (!res.ok) {
      setMsg(res.motivo === "ocupado" ? "Horário já ocupado." : "Agendamento não encontrado.");
      return;
    }
    setRemarcandoId(null);
    refetchAgenda();
    setMsg("Agendamento remarcado.");
  };

  const hojeCor = useHojeIso();
  const agora = new Date(agoraTs);
  const hojeIso = `${agora.getFullYear()}-${String(agora.getMonth() + 1).padStart(2, "0")}-${String(agora.getDate()).padStart(2, "0")}`;
  const minAgora = agora.getHours() * 60 + agora.getMinutes();
  const fimMin = (a: { hora: string; servico: string }) => {
    const [h, m] = a.hora.split(":").map(Number);
    return (h ?? 0) * 60 + (m ?? 0) + duracaoServico(a.servico);
  };
  const concluido = (a: { data: string; hora: string; servico: string }) =>
    a.data < hojeIso || (a.data === hojeIso && fimMin(a) <= minAgora);

  const agendamentos = agendaData?.agendamentos ?? [];
  const chave = (a: { data: string; hora: string }) => `${a.data} ${a.hora}`;
  const futuros = agendamentos.filter((a) => !concluido(a)).sort((x, y) => chave(x).localeCompare(chave(y)));
  const passados = agendamentos.filter((a) => concluido(a)).sort((x, y) => chave(y).localeCompare(chave(x)));

  if (!status?.autenticado) {
    return (
      <main className="min-h-screen bg-[#141414] text-stone-100 flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-6">
          <div className="flex items-center justify-center gap-3">
            <Scissors className="h-8 w-8 text-amber-500" />
            <h1 className="font-['Bebas_Neue'] text-3xl tracking-wide text-white">
              Painel {nome}
            </h1>
          </div>
          <form onSubmit={handleLogin} className="space-y-4 rounded-xl border border-white/10 bg-[#1b1b1b] p-6">
            <div>
              <label className="mb-1 block text-sm text-stone-400">Senha</label>
              <input
                type="password"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                className="w-full rounded-lg border border-white/10 bg-[#141414] px-4 py-3 text-white placeholder-stone-600 focus:border-amber-500 focus:outline-none"
                placeholder="Digite a senha"
              />
            </div>
            {erro && (
              <div className="flex items-center gap-2 text-sm text-rose-400">
                <AlertCircle className="h-4 w-4" />
                {erro}
              </div>
            )}
            <button
              type="submit"
              className="w-full rounded-lg bg-amber-600 px-4 py-3 font-semibold text-white transition hover:bg-amber-500"
            >
              Entrar
            </button>
          </form>
          <Link to="/painel" className="block text-center text-sm text-stone-500 hover:text-amber-500">
            ← Outros painéis
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#141414] text-stone-100">
      <header className="border-b border-white/10 bg-[#1b1b1b]">
        <div className="mx-auto flex max-w-5xl flex-col gap-4 p-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <Scissors className="h-7 w-7 text-amber-500" />
            <div>
              <h1 className="font-['Bebas_Neue'] text-2xl tracking-wide text-white">
                Painel {nome}
              </h1>
              <p className="text-xs text-stone-400">{BARBEIROS.find((b) => b.nome === nome)?.display}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {aviso.permissao === "default" ? (
              <button type="button" onClick={aviso.ativarNotificacoes} title="Permitir avisos do navegador quando esta aba estiver em segundo plano" className="flex items-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-sm text-stone-300 hover:bg-white/5">
                <Bell className="h-4 w-4" /> Ativar notificações
              </button>
            ) : aviso.permissao === "granted" ? (
              <span title="Notificações do navegador ativas enquanto o painel estiver aberto" aria-label="Notificações do navegador ativas" className="flex h-10 w-10 items-center justify-center text-amber-500"><Bell className="h-4 w-4" /></span>
            ) : (
              <span title={aviso.permissao === "denied" ? "Notificações bloqueadas. Permita-as nas configurações deste site no navegador." : "Notificações indisponíveis neste navegador ou conexão."} aria-label="Notificações do navegador indisponíveis" className="flex h-10 w-10 items-center justify-center text-stone-500"><BellOff className="h-4 w-4" /></span>
            )}
            <span
              title={aviso.somAtivo ? "Avisos sonoros ativos" : "O navegador libera o som após a primeira interação com a página"}
              aria-label={aviso.somAtivo ? "Avisos sonoros ativos" : "Som aguardando liberação do navegador"}
              className="flex h-10 w-10 items-center justify-center text-stone-300"
            >
              {aviso.somAtivo ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </span>
            <button
              onClick={() => refetchAgenda()}
              className="flex items-center gap-2 rounded-lg border border-white/10 px-4 py-2 text-sm text-stone-300 hover:bg-white/5"
            >
              <RefreshCw className="h-4 w-4" />
              Atualizar
            </button>
            <button
              onClick={handleSair}
              className="flex items-center gap-2 rounded-lg border border-white/10 px-4 py-2 text-sm text-stone-300 hover:bg-white/5"
            >
              <LogOut className="h-4 w-4" />
              Sair
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-5xl p-6">
        <div className="mb-6">
          <ResumoFaturamento atendimentos={agendamentos} />
        </div>
        {aviso.novas > 0 && (
          <div role="alert" className="mb-5 flex items-center justify-between gap-3 rounded-lg border border-amber-500/30 bg-amber-500/10 p-4 text-sm text-amber-200">
            <span>{aviso.novas} novo(s) agendamento(s) na sua agenda.</span>
            <button type="button" onClick={aviso.limparNovas} className="text-amber-500 hover:underline">Dispensar</button>
          </div>
        )}
        <div className="mb-6 flex gap-2 overflow-x-auto">
          {(["agenda", "servicos", "faturamento"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setAba(t)}
              className={`rounded-full px-5 py-2 text-sm font-medium transition ${
                aba === t
                  ? "bg-amber-600 text-white"
                  : "border border-white/10 text-stone-400 hover:text-white"
              }`}
            >
              {t === "agenda" ? "Agendamentos" : t === "servicos" ? "Serviços" : "Faturamento"}
            </button>
          ))}
        </div>

        {msg && (
          <div className="mb-4 flex items-center gap-2 rounded-lg border border-amber-500/20 bg-amber-500/10 px-4 py-3 text-sm text-amber-200">
            <CheckCircle2 className="h-4 w-4" />
            {msg}
          </div>
        )}

        {aba === "agenda" && (
          <section className="space-y-8">
            <div>
              <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-white">
                <Calendar className="h-5 w-5 text-amber-500" />
                Próximos agendamentos
              </h2>
              {futuros.length === 0 ? (
                <p className="text-stone-500">Nenhum agendamento futuro.</p>
              ) : (
                <div className="grid gap-3">
                  {futuros.map((a) => (
                    <div
                      key={a.id}
                      className={`rounded-xl border p-4 ${classesStatus(statusDoDia(a.data, hojeCor))}`}
                    >
                      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                          <p className="flex flex-wrap items-center gap-2 font-semibold text-white">
                            {a.nome}
                            <span
                              className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${rotuloStatus(statusDoDia(a.data, hojeCor)).classe}`}
                            >
                              {rotuloStatus(statusDoDia(a.data, hojeCor)).texto}
                            </span>
                          </p>
                          <p className="text-sm text-stone-400">
                            {a.servico} · {formatarData(a.data)} às {a.hora}
                          </p>
                          {a.telefone && (
                            <a
                              href={`https://wa.me/55${a.telefone.replace(/\D/g, "")}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="mt-1 inline-flex items-center gap-1 text-sm text-emerald-400 hover:underline"
                            >
                              <Phone className="h-3.5 w-3.5" />
                              {a.telefone}
                            </a>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          {remarcandoId === a.id ? (
                            <div className="flex flex-wrap items-center gap-2">
                              <input
                                type="date"
                                value={novaData}
                                min={hojeIso}
                                onChange={(e) => setNovaData(e.target.value)}
                                className="rounded-lg border border-white/10 bg-[#141414] px-3 py-2 text-sm text-white"
                              />
                              <select
                                value={novaHora}
                                onChange={(e) => setNovaHora(e.target.value)}
                                className="rounded-lg border border-white/10 bg-[#141414] px-3 py-2 text-sm text-white"
                              >
                                {horariosDisponiveis(nome, novaData, agendamentos.filter((r) => r.id !== a.id && r.data === novaData), duracaoServico(a.servico)).map((h) => (
                                  <option key={h} value={h}>
                                    {h}
                                  </option>
                                ))}
                              </select>
                              <button
                                onClick={() => handleRemarcar(a.id)}
                                className="rounded-lg bg-amber-600 px-3 py-2 text-sm font-medium text-white hover:bg-amber-500"
                              >
                                Salvar
                              </button>
                              <button
                                onClick={() => setRemarcandoId(null)}
                                className="rounded-lg border border-white/10 px-3 py-2 text-sm text-stone-300 hover:bg-white/5"
                              >
                                Cancelar
                              </button>
                            </div>
                          ) : (
                            <>
                              <button
                                onClick={() => iniciarRemarcar(a)}
                                className="rounded-lg border border-white/10 px-3 py-2 text-sm text-stone-300 hover:bg-white/5"
                              >
                                Remarcar
                              </button>
                              <button
                                onClick={() => handleCancelar(a.id)}
                                className="flex items-center gap-1 rounded-lg border border-rose-500/20 px-3 py-2 text-sm text-rose-400 hover:bg-rose-500/10"
                              >
                                <Trash2 className="h-4 w-4" />
                                Cancelar
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-white">
                <Clock className="h-5 w-5 text-stone-500" />
                Concluídos
              </h2>
              {passados.length === 0 ? (
                <p className="text-stone-500">Nenhum atendimento concluído.</p>
              ) : (
                <div className="grid gap-3 opacity-70">
                  {passados.map((a) => (
                    <div
                      key={a.id}
                      className={`rounded-xl border p-4 ${classesStatus(statusDoDia(a.data, hojeCor))}`}
                    >
                      <p className="flex flex-wrap items-center gap-2 font-semibold text-white">
                        {a.nome}
                        <span className="flex items-center gap-1 rounded-full bg-stone-700 px-2 py-0.5 text-[11px] font-medium text-stone-200">
                          <CheckCircle2 className="h-3 w-3" /> Concluído
                        </span>
                      </p>
                      <p className="text-sm text-stone-400">
                        {a.servico} · {formatarData(a.data)} às {a.hora}
                      </p>
                      {a.telefone && (
                        <a
                          href={`https://wa.me/55${a.telefone.replace(/\D/g, "")}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-1 inline-flex items-center gap-1 text-sm text-emerald-400 hover:underline"
                        >
                          <Phone className="h-3.5 w-3.5" />
                          {a.telefone}
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>
        )}

        {aba === "servicos" && (
          <section>
            <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-white">
              <Scissors className="h-5 w-5 text-amber-500" />
              Tabela de serviços
            </h2>
            <div className="overflow-hidden rounded-xl border border-white/10">
              <table className="w-full text-left text-sm">
                <thead className="bg-[#1b1b1b] text-stone-400">
                  <tr>
                    <th className="px-4 py-3">Serviço</th>
                    <th className="px-4 py-3">Tempo</th>
                    <th className="px-4 py-3">Preço</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10 bg-[#141414]">
                  {SERVICOS.map((s) => (
                    <tr key={s.nome}>
                      <td className="px-4 py-3 text-white">{s.nome}</td>
                      <td className="px-4 py-3 text-stone-400">{s.tempo}</td>
                      <td className="px-4 py-3 font-medium text-amber-500">{s.preco}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}

        {aba === "faturamento" && (
          <section className="space-y-8">
            <FaturamentoPorServico resumo={calcularFaturamento(agendamentos, agoraTs)} />
          </section>
        )}
      </div>
    </main>
  );
}
