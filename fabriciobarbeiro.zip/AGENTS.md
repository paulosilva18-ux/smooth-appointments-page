<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Use `src/lib/duracao.ts` as the shared source of truth for minute-accurate booking availability and turn fitting; booking and rescheduling must apply the same rules.
- Use a shared browser-side booking-alert hook in both administrative views; frequent polling preserves server-side access scoping, while audio automatically unlocks on the first permitted browser gesture.
- Keep browser notification permission and new-booking detection in the shared alert hook; this keeps both panels scoped to their existing authorized agenda feeds and avoids duplicate initial alerts.
- Scheduled reminders use a server-only response helper that authenticates before database access and skips unconfigured providers; this isolates background failures and prevents unauthenticated privileged processing.
- Share integer-cent revenue calculations and service breakdowns across both administrative entry points using existing authorized agenda feeds and historical booking prices; this keeps totals consistent without changing records or widening access.
- Keep per-day inclusive final-start limits in the ULTIMO_INICIO map in `src/lib/horarios.ts` and apply them only to the matching final shift through `src/lib/duracao.ts`; this lets services start up to that limit without weakening morning breaks, overlap checks or shared booking/rescheduling validation.
